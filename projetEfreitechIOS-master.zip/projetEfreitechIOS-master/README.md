# projetEfreitechIOS
projet développement mobile IOS : Swift

Bonus :
  - Design different sur Ipad
  - Ajouter les messages d'erreurs (pas de prints), directement sur l'interface via des labels 
  - Ajouter une validation de l'email et du password 
    - email verification d'un @
    - password caractere < 5 
  - Un easter egg :D (surprise)
  

