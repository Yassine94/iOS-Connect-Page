//
//  TetrisViewDelegate.swift
//  Project
//
//  Created by Yassine FATIHI / Maxime GOUENARD on 14/02/2019.
//  Copyright © 2019 Yassine FATIHI / Maxime GOUENARD All rights reserved.
//

import Foundation

protocol TetrisViewDelegate {
    func backToProfile()
}
